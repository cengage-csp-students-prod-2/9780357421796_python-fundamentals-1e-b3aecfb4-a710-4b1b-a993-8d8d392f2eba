Distance = 60
Time = 3
Knots = Distance/1.15078
Feet = 60*5280 
Seconds = 3*3600
MPH = Distance/Time
FPS = Feet/Seconds
print("The speed in knots is:", Knots)
print("The speed in miles per hour is", MPH)
print("The speed in feet per second is",FPS)